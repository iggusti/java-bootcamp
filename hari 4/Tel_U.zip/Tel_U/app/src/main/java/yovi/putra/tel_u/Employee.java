package yovi.putra.tel_u;

import android.os.Parcel;
import android.os.Parcelable;

public class Employee implements Parcelable {
    private String name;
    private int umur;
    private boolean married;

    public Employee() {
    }

    protected Employee(Parcel in) {
        name = in.readString();
        umur = in.readInt();
        married = in.readByte() != 0;
    }

    public static final Creator<Employee> CREATOR = new Creator<Employee>() {
        @Override
        public Employee createFromParcel(Parcel in) {
            return new Employee(in);
        }

        @Override
        public Employee[] newArray(int size) {
            return new Employee[size];
        }
    };

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getUmur() {
        return umur;
    }

    public void setUmur(int umur) {
        this.umur = umur;
    }

    public boolean isMarried() {
        return married;
    }

    public void setMarried(boolean married) {
        this.married = married;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(name);
        parcel.writeInt(umur);
        parcel.writeByte((byte) (married ? 1 : 0));
    }
}
