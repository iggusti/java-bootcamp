package yovi.putra.tel_u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        getIntentdData();
    }


    private void getIntentdData(){
        final Employee employee = getIntent().getParcelableExtra("data");
        EditText nama = findViewById(R.id.edtNama);
        EditText umur = findViewById(R.id.edtUmur);
        EditText married = findViewById(R.id.edtStatus);

        nama.setText(employee.getName());
        umur.setText(employee.getUmur() + "");
        married.setText(employee.isMarried() + "");

        Button btBack = findViewById(R.id.btnBack);
        btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                employee.setName("Lutfi");
                Intent intent = new Intent();
                intent.putExtra("data", employee);
                setResult(99, intent);
                finish();

            }
        });
    }

}
