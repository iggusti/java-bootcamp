package yovi.putra.tel_u;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txtNama;
    Employee employee = new Employee();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonNext = findViewById(R.id.btnNext);
        txtNama = findViewById(R.id.txtNama);


        employee.setName("Yovi");
        employee.setUmur(26);
        employee.setMarried(false);
        txtNama.setText(employee.getName());

        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoDetailActivity();
            }
        });
    }

    private void gotoDetailActivity() {



        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra("data", employee);
        startActivityForResult(intent, 88);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        employee = data.getParcelableExtra("data");
        txtNama.setText(employee.getName());
    }
}

