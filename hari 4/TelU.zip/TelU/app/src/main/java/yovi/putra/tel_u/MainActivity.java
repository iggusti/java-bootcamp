package yovi.putra.tel_u;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnLongClickListener, View.OnClickListener {
    EditText txtPanjang,txtLebar,txtTinggi;
    TextView txtHasil;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtPanjang = findViewById(R.id.editText);
        txtLebar = findViewById(R.id.editText2);
        txtTinggi = findViewById(R.id.editText3);
        Button btnHitung = findViewById(R.id.btnHitung);
        txtHasil = findViewById(R.id.txtHasil);


        btnHitung.setOnClickListener(this);
        btnHitung.setOnLongClickListener(this);
    }

    @Override
    public boolean onLongClick(View view) {
        Toast.makeText(this, "Hello Reza", Toast.LENGTH_SHORT).show();
        return false;
    }

    @Override
    public void onClick(View view) {
        //Toast.makeText(MainActivity.this,"hello",Toast.LENGTH_SHORT).show();
        int panjang = Integer.parseInt(txtPanjang.getText().toString());
        int lebar = Integer.parseInt(txtLebar.getText().toString());
        int tinggi = Integer.parseInt(txtTinggi.getText().toString());

        final int hasil = panjang * lebar * tinggi;
        txtHasil.setText(hasil + " ");
    }
}
