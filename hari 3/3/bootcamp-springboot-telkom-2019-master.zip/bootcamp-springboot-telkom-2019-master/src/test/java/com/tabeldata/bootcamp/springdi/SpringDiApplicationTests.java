package com.tabeldata.bootcamp.springdi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDiApplicationTests {

	@Test
	void contextLoads() {
	}

}
