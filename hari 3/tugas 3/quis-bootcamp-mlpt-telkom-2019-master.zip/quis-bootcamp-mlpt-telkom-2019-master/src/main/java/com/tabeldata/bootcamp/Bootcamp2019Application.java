package com.tabeldata.bootcamp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bootcamp2019Application {

	public static void main(String[] args) {
		SpringApplication.run(Bootcamp2019Application.class, args);
	}

}
