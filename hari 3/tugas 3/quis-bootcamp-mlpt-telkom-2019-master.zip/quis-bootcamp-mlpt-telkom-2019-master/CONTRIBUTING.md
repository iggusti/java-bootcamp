## Cara Mengerjakan

- Download repository ini, didalamnya terdapat template project springboot.
- Anda di perbolehkan mencari ref di internet, dari buku, atau apa pun itu. yang **tidak boleh re-upload tugas dari teman**
- Untuk soal teori, silahkan isi saja langsung di file `README.md`
- Untuk soal praktek, silakhan kerjakan di folder `src`

## Cara Mengupulkan

- yang dikirimkan hanya folder `src` dan file `README.md` berbentuk zip dengan nama file `nama_lengkap.zip`
- kirim melalui email [dimas.maryanto@tabeldata.com](mailto:dimas.maryanto@tabeldata.com?subject=bootcamp-mlpt-2019) dengan subject `bootcamp-telkom-mlpt-2019`
- Paling lambat tanggal **23 October 2019 pukul 23.59**
