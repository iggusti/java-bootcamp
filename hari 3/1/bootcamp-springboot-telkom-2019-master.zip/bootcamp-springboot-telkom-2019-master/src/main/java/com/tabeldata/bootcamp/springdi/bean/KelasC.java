package com.tabeldata.bootcamp.springdi.bean;

public class KelasC {

    private String namaLengkap;

    public String getNamaLengkap() {
        return namaLengkap;
    }

    public void setNamaLengkap(String namaLengkap) {
        this.namaLengkap = namaLengkap;
    }
}
