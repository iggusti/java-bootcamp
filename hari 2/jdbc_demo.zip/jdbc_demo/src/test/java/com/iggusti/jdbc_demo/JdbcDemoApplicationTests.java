package com.iggusti.jdbc_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
